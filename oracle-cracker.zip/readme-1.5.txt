Readme-1.5.txt

Cracker-v2.0(1.5).sql - vesion 1.5
=======================================

Fixed a bug in the debug code. The variable debugv was not long enough to hold the
word "OFF". Thanks to Edwin Uy for locating this. 


Cracker-v2.0(1.4).sql - vesion 1.4
=======================================

I have modified the cracker to allow it to only print out "WEAK" instead of the actual
password. The indicators at the right hand side are still there so you can tell whether
the password cracked was a dictionary word or a default password, username=password or
a brute forced password. 

To modifiy the code simply set the line in the code:

define debug = 'OFF'

to 

define debug = 'ON'


Cracker-v2.0(1.3).sql - vesion 1.3
=======================================

Two bug fixes:
1) The password record element had its size increased to 38 characters to take care of
   cases where there could be an impossible password set to the maximum length of the
   sys.user$.password column. The size also includes room for the report text.
2) The usernames are now coated with double quotes. This is to ensure that "invisible" 
   usernames such as " " or "\t" are shown in the report.

Cracker-v2.0(1.2).sql - vesion 1.2
=======================================

First public release.